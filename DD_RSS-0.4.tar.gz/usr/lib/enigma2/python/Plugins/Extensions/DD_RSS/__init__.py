# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/DD_RSS/__init__.py
pass